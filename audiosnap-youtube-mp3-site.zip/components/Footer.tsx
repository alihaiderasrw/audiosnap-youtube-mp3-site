import Link from "next/link";
import { site } from "@/lib/site";
export default function Footer(){ return <footer className="footer"><div className="container footer-grid">
  <div><div className="brand">{site.name}</div><p>A clean, responsible audio conversion interface for content you are authorized to download or convert.</p></div>
  <div><h3>Converters</h3><Link href="/youtube-to-mp3">YouTube to MP3</Link><Link href="/youtube-to-wav">YouTube to WAV</Link><Link href="/youtube-audio-converter">Audio Converter</Link></div>
  <div><h3>Resources</h3><Link href="/how-it-works">How It Works</Link><Link href="/faq">FAQ</Link><Link href="/blog">Blog</Link><Link href="/contact">Contact</Link></div>
  <div><h3>Legal</h3><Link href="/privacy-policy">Privacy Policy</Link><Link href="/terms">Terms</Link><Link href="/disclaimer">Disclaimer</Link></div>
</div><div className="container copyright">© {new Date().getFullYear()} {site.name}. Use only with content you have permission to download or convert.</div></footer>}
