"use client";
import { useState } from "react";

export default function Converter({format="mp3"}:{format?:"mp3"|"wav"}) {
  const [url,setUrl]=useState(""); const [quality,setQuality]=useState("192"); const [status,setStatus]=useState<"idle"|"loading"|"success"|"error">("idle"); const [message,setMessage]=useState(""); const [result,setResult]=useState<any>(null);
  async function paste(){ try{ setUrl(await navigator.clipboard.readText()); }catch{ setMessage("Clipboard access is unavailable. Paste the URL manually."); setStatus("error"); } }
  async function submit(e:React.FormEvent){ e.preventDefault(); setStatus("loading"); setMessage(""); setResult(null);
    try{ const r=await fetch("/api/convert",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({url,format,quality})}); const d=await r.json(); if(!r.ok) throw new Error(d.message||"We couldn't process this URL. Please check the link and try again."); setResult(d); setStatus("success"); }
    catch(err:any){ setMessage(err.message||"The conversion service is temporarily unavailable. Please try again later."); setStatus("error"); }
  }
  return <div id="converter" className="converter-card">
    <form onSubmit={submit}>
      <label htmlFor="yt-url">YouTube URL</label><div className="input-row"><input id="yt-url" value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." inputMode="url" required/><button type="button" className="ghost" onClick={paste}>Paste</button></div>
      <div className="options"><div><label htmlFor="quality">Audio quality</label><select id="quality" value={quality} onChange={e=>setQuality(e.target.value)}><option value="128">128 kbps</option><option value="192">192 kbps</option><option value="256">256 kbps</option><option value="320">320 kbps</option></select></div><div className="format-pill">{format.toUpperCase()}</div></div>
      <button className="button wide" disabled={status==="loading"}>{status==="loading"?"Processing…":`Convert to ${format.toUpperCase()}`}</button>
    </form>
    {status==="loading"&&<div className="progress"><span></span><p>Sending your request securely…</p></div>}
    {status==="error"&&<div className="alert error">{message}</div>}
    {status==="success"&&<div className="result"><h3>Conversion ready</h3>{result?.title&&<p>{result.title}</p>}{result?.downloadUrl?<a className="button" href={result.downloadUrl}>Download {format.toUpperCase()}</a>:<p>The connected provider did not return a download URL.</p>}<button className="ghost" onClick={()=>{setUrl("");setStatus("idle");setResult(null)}}>Try another URL</button></div>}
    <p className="notice">Use this tool only with content you are authorized to download or convert.</p>
  </div>
}
