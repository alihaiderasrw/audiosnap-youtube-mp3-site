import Link from "next/link";
import { site } from "@/lib/site";

export default function Header() {
  return <header className="site-header"><div className="container nav-wrap">
    <Link className="brand" href="/">{site.name}</Link>
    <nav className="nav-links" aria-label="Primary navigation">
      <Link href="/youtube-to-mp3">YouTube to MP3</Link>
      <Link href="/youtube-to-wav">YouTube to WAV</Link>
      <Link href="/youtube-downloader">YouTube Downloader</Link>
      <Link href="/how-it-works">How It Works</Link>
      <Link href="/faq">FAQ</Link>
      <Link href="/blog">Blog</Link>
    </nav>
    <Link className="button small" href="#converter">Start Converting</Link>
  </div></header>;
}
