import Converter from "./Converter";
export default function ContentPage({title,intro,format="mp3",children}:{title:string;intro:string;format?:"mp3"|"wav";children?:React.ReactNode}){
 return <main><section className="hero compact"><div className="container narrow"><span className="eyebrow">Fast • Simple • Mobile Friendly</span><h1>{title}</h1><p>{intro}</p><Converter format={format}/></div></section>{children}</main>
}
