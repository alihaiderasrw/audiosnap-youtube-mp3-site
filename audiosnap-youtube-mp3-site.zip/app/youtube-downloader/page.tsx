import ContentPage from "@/components/ContentPage";
export const metadata={title:"YouTube Downloader",description:"A responsible download workflow for eligible content you are authorized to save."};
export default function Page(){return <ContentPage title="YouTube Downloader" intro="A simple interface for eligible content, with clear validation and responsible-use guidance."/>}
