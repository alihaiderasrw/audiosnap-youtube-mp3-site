import { NextRequest, NextResponse } from "next/server";
import { isSupportedYoutubeUrl, requestConversion } from "@/lib/conversion";

const allowedQualities = new Set(["128", "192", "256", "320"]);
const recent = new Map<string, number[]>();

function rateLimited(ip: string) {
  const now = Date.now();
  const windowMs = 60_000;
  const max = 10;
  const hits = (recent.get(ip) || []).filter((t) => now - t < windowMs);
  if (hits.length >= max) return true;
  hits.push(now);
  recent.set(ip, hits);
  return false;
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  if (rateLimited(ip)) {
    return NextResponse.json({ message: "Too many requests. Please wait a moment and try again." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  if (!body || typeof body.url !== "string") {
    return NextResponse.json({ message: "Please enter a valid YouTube URL." }, { status: 400 });
  }

  const format = body.format === "wav" ? "wav" : "mp3";
  const quality = String(body.quality || "192");
  if (!isSupportedYoutubeUrl(body.url)) {
    return NextResponse.json({ message: "Please enter a valid supported YouTube URL." }, { status: 400 });
  }
  if (!allowedQualities.has(quality)) {
    return NextResponse.json({ message: "Unsupported audio quality selected." }, { status: 400 });
  }

  const result = await requestConversion({ url: body.url, format, quality });
  if (!result.ok) {
    return NextResponse.json({ code: result.code, message: result.message }, { status: result.status });
  }
  return NextResponse.json(result.data);
}
