import ContentPage from "@/components/ContentPage";
export const metadata={title:"YouTube to MP3 Converter for Mobile",description:"A responsive YouTube to MP3 interface for Android, iPhone and tablets."};
export default function Page(){return <ContentPage title="YouTube to MP3 Converter for Mobile" intro="The converter is optimized for touch screens, compact layouts and mobile browsers."/>}
