import ContentPage from "@/components/ContentPage";
export const metadata={title:"YouTube to MP3 Online",description:"Use a browser-based interface to convert eligible YouTube links to MP3 without installing desktop software."};
export default function Page(){return <ContentPage title="YouTube to MP3 Online" intro="A browser-first MP3 conversion interface designed for clear steps, responsive layouts and transparent error handling."/>}
