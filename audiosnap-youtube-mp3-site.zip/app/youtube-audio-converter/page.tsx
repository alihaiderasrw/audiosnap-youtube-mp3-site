import ContentPage from "@/components/ContentPage";
export const metadata={title:"YouTube Audio Converter",description:"Convert supported YouTube links into an available audio format using a server-side provider integration."};
export default function Page(){return <ContentPage title="YouTube Audio Converter" intro="Choose an audio format supported by your configured backend processing service."/>}
