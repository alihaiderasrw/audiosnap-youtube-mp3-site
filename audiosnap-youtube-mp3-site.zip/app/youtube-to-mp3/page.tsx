import ContentPage from "@/components/ContentPage";
export const metadata={title:"YouTube to MP3 Converter Online",description:"Convert eligible YouTube video links to MP3 with a clean, mobile-friendly interface and supported audio quality options."};
export default function Page(){return <ContentPage title="YouTube to MP3 Converter Online" intro="Paste a supported YouTube URL, choose an available bitrate and send it to the configured conversion service."/>}
