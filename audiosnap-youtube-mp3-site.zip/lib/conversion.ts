export type ConvertInput = { url: string; format: "mp3" | "wav"; quality: string };

export function isSupportedYoutubeUrl(value: string) {
  try {
    const url = new URL(value);
    const host = url.hostname.replace(/^www\./, "");
    return ["youtube.com", "m.youtube.com", "youtu.be"].includes(host);
  } catch {
    return false;
  }
}

export async function requestConversion(input: ConvertInput) {
  const endpoint = process.env.CONVERSION_API_URL;
  const apiKey = process.env.CONVERSION_API_KEY;

  if (!endpoint || !apiKey) {
    return {
      ok: false as const,
      status: 501,
      code: "PROVIDER_NOT_CONFIGURED",
      message: "Conversion provider is not configured yet. Connect an authorized processing service in the server environment.",
    };
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(input),
    cache: "no-store",
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    return {
      ok: false as const,
      status: response.status,
      code: data?.code || "PROVIDER_ERROR",
      message: data?.message || "The conversion service is temporarily unavailable. Please try again later.",
    };
  }

  return { ok: true as const, status: 200, data };
}
